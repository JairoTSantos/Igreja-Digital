<?php

return [
    'db' => [
        'host' => 'localhost',
        'username' => 'root',
        'password' => 'root',
        'database' => 'igreja'
    ],
    'app' => [
        'app_name' => 'Igreja Digital',
        'nome_igreja' => 'Primeira Igreja Batista do Gama',
        'sigla_igreja' => 'PIBGama',
        'endereco_igreja' => 'Setor leste lote 2',
        'municipio_igreja' => 'Gama',
        'estado_igreja' => 'DF',
        'site_igreja' => 'pibgama.com.br',
        'permitted_files' => ['png', 'jpg', 'jpeg', 'docx', 'pdf', 'doc', 'psd', 'ai', 'zip', 'mp4', 'mov'],
        'maximum_file_size' => 100,
    ]
];
