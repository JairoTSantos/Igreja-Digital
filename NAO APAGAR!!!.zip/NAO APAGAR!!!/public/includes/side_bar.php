<div class="border-end bg-white" id="sidebar-wrapper">
    <div class="sidebar-heading border-bottom bg-light">Start Bootstrap</div>
    <div class="list-group list-group-flush">
        <p style="margin-left: 10px; margin-top:20px;font-weight: bolder;" class="text-muted"><i class="fas fa-bars"></i> Gestão de pessoas</p>
        <a class="list-group-item list-group-item-action list-group-item-light px-4" href="pessoas.php"><i class="fa-solid fa-users"></i> Pessoas</a>
        <a class="list-group-item list-group-item-action list-group-item-light px-4" href="cargos.php"><i class="fa-solid fa-briefcase"></i> Cargos</a>
        <a class="list-group-item list-group-item-action list-group-item-light px-4" href="familias.php"><i class="fa-solid fa-people-roof"></i> Famílias</a>
    </div>
</div>